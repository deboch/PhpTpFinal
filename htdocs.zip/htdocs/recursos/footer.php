
<!-- inject:js -->
<script src="assets/js/jquery.slim.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- endinject -->
<!-- Custom js for this page -->
<!-- End custom js for this page -->
</body>
</html>



