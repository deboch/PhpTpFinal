<?php
include('config.php');

 $config = getConfigAsArray();

function getConexion(){
    $host = $config['database']['host'];
    $user =$config['database']['user'];
    $pass = $config['database']['pass'];
    $db= $config['database']['db'];;
$conexion = mysqli_connect($host, $user, $pass, $db);
   
if(mysqli_connect_errno()){
    echo 'No se pudo conectar a la base de datos : '.mysqli_connect_error();
   } 
    return $conexion;
}

?>
