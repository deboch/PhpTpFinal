<?php
require_once 'Conexion.php';
session_start();
if(!isset($_SESSION['administrador'])){
    header("Location: index.php");
}
?>


<?php
include('recursos/header.php');
include('vista/vistaAdmin.php');
include('recursos/footer.php');
?>
