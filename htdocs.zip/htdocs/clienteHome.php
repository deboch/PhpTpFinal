<?php
require_once 'Conexion.php';
session_start();
if(!isset($_SESSION['cliente'])){
    header("Location: index.php");
}
?>


<?php
include('recursos/header.php');
include('vistaCliente.php');
include('recursos/footer.php');
?>
