<?php

//var_dump($_SESSION);
$usuario = $_SESSION['cliente'] ;

?>



<body>
<h1>Bienvenido <?php echo $usuario ?> </h1>

<li class="nav-item">
    <a class="nav-link" href="CerrarSession.php"><i class="fas fa-sign-out-alt"></i> Cerrar sesión</a>
    <a class="nav-link" href="crearReserva.php"><i class="fas fa-sign-out-alt"></i> crear reserva</a>
    <form class="form-inline" method="post" action="/clienteHome.php">
        <input class="form-control mr-sm-3" name="busca" type="search" placeholder="Cabina" aria-label="Search">
        <button class="btn submit buscar" type="submit" >Buscar</button>
    </form>
</li>

<table class="table">
    <thead>
    <tr>
        <th scope="col">Nro Vuelo</th>
        <th scope="col">fecha</th>
        <th scope="col">duracion</th>
        <th scope="col">cabina</th>
        <th scope="col">Tipo vuelo</th>
        <th scope="col">Equipo</th>

    </tr>
    </thead>
    <tbody>
    <?php
        include("controlador/controlador_vistaCliente.php");
    ?>

    </tbody>
</table>
</body>
</html>