<?php
//include("vista/vistaAdmin.php")
include("modelo/modelo_vistaAdmin.php");

?>