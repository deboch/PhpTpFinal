<?php
include("modelo/modelo_vistaCliente.php");
//include("vista/vistaCliente.php")
?>