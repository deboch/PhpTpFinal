<?php
    include("Conexion.php");
    $conexion=mysqli_connect("localhost","root", "1234","pokedex");
        $sql="SELECT * FROM vuelos";
        $result=mysqli_query($conn,$sql);


        while ($row=mysqli_fetch_assoc($result))
        {
            echo "<tr>";
            echo "<td>".$row['id']."</td>";
            echo "<td>".$row['nombre']."</td>";
            echo "<td>".$row['tipo']."</td>";
            echo "<td>".$row['imagen']."</td>";
            echo "<td><a href=\"delete&&id= a><td>";
            echo "</tr>";
        }
?>