<?php
    include("Conexion.php");

    $conexion=mysqli_connect("localhost","root", "1234","tpfinal");
    $sql="SELECT * FROM vuelo";
    $result=mysqli_query($conn,$sql);

    $busca= "";
    $busca=$_POST['busca'];

    if($busca== ""){
        $sql="SELECT * FROM vuelo";
        $result=mysqli_query($conn,$sql);

    }else{$sql = "SELECT * FROM vuelo WHERE cabina LIKE '%".$busca."%'";
        $result=mysqli_query($conn,$sql );
        if(mysqli_query($conn,$sql )) {echo "Resultado busqueda";}else{echo "No se encontro coincidencias";}
    }
    while ($row=mysqli_fetch_assoc($result))
    {
        echo "<tr>";
        echo "<td>".$row['id']."</td>";
        echo "<td>".$row['fecha']."</td>";
        echo "<td>".$row['duracion']."</td>";
        echo "<td>".$row['cabina']."</td>";
        echo "<td>".$row['tipo_vuelo']."</td>";
        echo "<td>".$row['equipo']."</td>";
      //  echo "<td><a href=\"delete&&id= a><td>";
        echo "</tr>";
    }
    $longitud = 6;
    function generarCodigo($longitud) {
    $key = '';
    $pattern = '1234567890abcdefghijklmnopqrstuvwxyz';
    $max = strlen($pattern)-1;
    for($i=0;$i < $longitud;$i++) $key .= $pattern{mt_rand(0,$max)};
    return $key;
    echo generarCodigo(6); 
}
?>